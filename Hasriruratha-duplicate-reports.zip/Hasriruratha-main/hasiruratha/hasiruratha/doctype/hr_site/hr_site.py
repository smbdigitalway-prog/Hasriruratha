# Copyright (c) 2026, Hasiru Ratha and contributors
# For license information, please see license.txt
"""
HR Site - with duplicate detection.

A NEW site is flagged "Needs Review" (never blocked) when, among sites of the same type that
are not Merged, there is one that is
  * within DUPLICATE_RADIUS_M metres, OR
  * on the same road + area and within SAME_ROAD_RADIUS_M metres.
(Road+area alone would flag every site on a long road, so it is paired with a distance cap.)
The admin then approves it as a new site or merges it into the existing one.
"""
import json
import math

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt

DUPLICATE_RADIUS_M = 25
SAME_ROAD_RADIUS_M = 150
NEAR_ME_RADIUS_M = 300
ADMIN_ROLES = {"HR Admin", "System Manager", "Administrator"}


def haversine(lat1, lng1, lat2, lng2):
	r = 6371000.0
	p1, p2 = math.radians(lat1), math.radians(lat2)
	dphi, dl = p2 - p1, math.radians(lng2 - lng1)
	a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
	return 2 * r * math.asin(math.sqrt(a))


def _norm(s):
	return " ".join(str(s or "").lower().split())


def get_nearby(lat, lng, radius=NEAR_ME_RADIUS_M, site_type=None, exclude=None):
	"""Sites within `radius` metres, closest first. Merged sites are never returned."""
	lat, lng, radius = flt(lat), flt(lng), flt(radius)
	if not (lat and lng):
		return []
	dlat = radius / 111320.0
	dlng = radius / (111320.0 * max(math.cos(math.radians(lat)), 0.01))
	filters = {
		"gps_lat": ["between", [lat - dlat, lat + dlat]],
		"gps_lng": ["between", [lng - dlng, lng + dlng]],
		"status": ["!=", "Merged"],
	}
	if site_type:
		filters["site_type"] = site_type
	rows = frappe.get_all(
		"HR Site", filters=filters,
		fields=["name", "site_id", "site_name", "site_type", "status", "road", "area",
		        "zone_id", "tree_count", "gps_lat", "gps_lng", "photo_url"],
		limit_page_length=0,
	)
	out = []
	for r in rows:
		if exclude and r.name == exclude:
			continue
		d = haversine(lat, lng, flt(r.gps_lat), flt(r.gps_lng))
		if d <= radius:
			r["distance_m"] = round(d)
			out.append(r)
	return sorted(out, key=lambda x: x["distance_m"])


def find_duplicate(lat, lng, site_type, road, area, exclude=None):
	for c in get_nearby(lat, lng, SAME_ROAD_RADIUS_M, site_type or "spot", exclude):
		if c["distance_m"] <= DUPLICATE_RADIUS_M:
			return c
		if _norm(road) and _norm(road) == _norm(c.road) and _norm(area) == _norm(c.area):
			return c
	return None


class HRSite(Document):
	def validate(self):
		self.flag_possible_duplicate()
		if flt(self.gps_lat) and flt(self.gps_lng):
			self.latitude, self.longitude = flt(self.gps_lat), flt(self.gps_lng)

	def flag_possible_duplicate(self):
		if not self.is_new() or self.flags.ignore_duplicate_check or self.possible_duplicate_of:
			return
		if not (flt(self.gps_lat) and flt(self.gps_lng)):
			return
		match = find_duplicate(self.gps_lat, self.gps_lng, self.site_type, self.road, self.area,
		                       exclude=self.name)
		if match:
			self.status = "Needs Review"
			self.possible_duplicate_of = match["name"]

	def after_insert(self):
		if self.status == "Needs Review" and self.possible_duplicate_of:
			from hasiruratha.hasiruratha.doctype.hr_duplicate_report.hr_duplicate_report import create_for_site

			create_for_site(self)
			_notify_admins(self)

	def on_trash(self):
		# Whatever way a site is deleted (button, Desk Delete, bulk), a copy is kept in HR Deleted Site.
		if not frappe.db.exists("HR Deleted Site", {"original_site": self.name, "restored_site": ["is", "not set"]}):
			_archive_site(self, _("Deleted from the desk"), None, [])


def _notify_admins(doc):
	admins = frappe.get_all("Has Role", {"role": "HR Admin", "parenttype": "User"}, pluck="parent")
	for u in set(admins) - {"Administrator", "Guest"}:
		if not frappe.db.get_value("User", u, "enabled"):
			continue
		frappe.get_doc({
			"doctype": "ToDo", "allocated_to": u, "reference_type": "HR Site",
			"reference_name": doc.name, "priority": "Medium",
			"description": _("Possible duplicate site: {0} is close to {1}. Please approve or merge.").format(
				doc.name, doc.possible_duplicate_of),
		}).insert(ignore_permissions=True)


def _require_admin():
	if not (ADMIN_ROLES & set(frappe.get_roles())):
		frappe.throw(_("Only an admin can do this"), frappe.PermissionError)


def _close_todos(name):
	for t in frappe.get_all("ToDo", {"reference_type": "HR Site", "reference_name": name, "status": "Open"}, pluck="name"):
		frappe.db.set_value("ToDo", t, "status", "Closed")


@frappe.whitelist()
def approve_site(name):
	"""Admin: this is genuinely a different site."""
	_require_admin()
	doc = frappe.get_doc("HR Site", name)
	_resolve_report(name, "Kept as New")
	doc.flags.ignore_duplicate_check = True
	doc.status, doc.possible_duplicate_of = "Identified", None
	doc.save(ignore_permissions=True)
	_close_todos(name)
	return {"success": True}


@frappe.whitelist()
def merge_site(name, into=None):
	"""Admin: same place as `into` (default: Possible Duplicate Of). Moves trees, visits, reports."""
	_require_admin()
	dup = frappe.get_doc("HR Site", name)
	target = into or dup.possible_duplicate_of
	if not target or target == name or not frappe.db.exists("HR Site", target):
		frappe.throw(_("Choose a different existing site to merge into"))
	_resolve_report(name, "Merged", _("Merged into {0}").format(target))
	for dt in ("HR Tree", "HR Visit", "HR Condition", "HR Tree Report"):
		frappe.db.sql("update `tab%s` set site_id=%%s where site_id=%%s" % dt, (target, name))
	count = frappe.db.count("HR Tree", {"site_id": target})
	frappe.db.set_value("HR Site", target, "tree_count", count)
	frappe.db.set_value("HR Site", name, {
		"status": "Merged", "possible_duplicate_of": target, "tree_count": 0,
		"notes": ((dup.notes or "") + "\nMerged into %s by %s" % (target, frappe.session.user)).strip(),
	})
	_close_todos(name)
	return {"success": True, "merged_into": target}


def _site_card(name):
	if not name:
		return None
	s = frappe.db.get_value("HR Site", name, ["name", "site_name", "road", "area", "zone_id", "gps_lat", "gps_lng",
	                                          "tree_count", "photo_url", "status"], as_dict=True)
	if not s:
		return None
	s["photo"] = s.photo_url or frappe.db.get_value("HR Tree", {"site_id": name, "photo_url": ["is", "set"]}, "photo_url")
	return s


@frappe.whitelist()
def duplicate_info(name):
	"""Both sites side by side (with photos) so the admin can tell if they are the same place."""
	_require_admin()
	a = _site_card(name)
	b = _site_card(frappe.db.get_value("HR Site", name, "possible_duplicate_of"))
	dist = None
	if a and b and flt(a.gps_lat) and flt(b.gps_lat):
		dist = round(haversine(flt(a.gps_lat), flt(a.gps_lng), flt(b.gps_lat), flt(b.gps_lng)))
	return {"this": a, "other": b, "distance_m": dist}


@frappe.whitelist(methods=["POST"])
def delete_duplicate(name, reason=None):
	"""Admin: delete a duplicate site. Its trees and records move to the original; a full copy is kept in HR Deleted Site."""
	_require_admin()
	reason = (reason or "").strip()
	if not reason:
		frappe.throw(_("Please give a reason"))
	doc = frappe.get_doc("HR Site", name)
	target = doc.possible_duplicate_of
	if target and (target == name or not frappe.db.exists("HR Site", target)):
		target = None
	trees = frappe.get_all("HR Tree", {"site_id": name}, pluck="name")
	linked = sum(frappe.db.count(dt, {"site_id": name}) for dt in ("HR Visit", "HR Condition", "HR Tree Report"))
	if (trees or linked) and not target:
		frappe.throw(_("This site has trees or records. Set Possible Duplicate Of first, so they can be moved there."))

	archive = _archive_site(doc, reason, target, trees)
	_resolve_report(name, "Deleted", _("Deleted: {0}").format(reason), deleted_site=archive.name)

	if target:
		for dt in ("HR Tree", "HR Visit", "HR Condition", "HR Tree Report"):
			frappe.db.sql("update `tab%s` set site_id=%%s where site_id=%%s" % dt, (target, name))
		frappe.db.set_value("HR Site", target, "tree_count", frappe.db.count("HR Tree", {"site_id": target}))
	if frappe.db.exists("DocType", "HR Citizen Planting"):
		frappe.db.sql("update `tabHR Citizen Planting` set site=%s where site=%s", (target, name))
	_close_todos(name)
	frappe.delete_doc("HR Site", name, force=True, ignore_permissions=True)
	return {"success": True, "archive": archive.name, "moved_to": target}


def _resolve_report(site_name, status, remarks=None, **extra):
	from hasiruratha.hasiruratha.doctype.hr_duplicate_report.hr_duplicate_report import create_for_site, resolve

	if not frappe.db.exists("HR Duplicate Report", {"site": site_name, "status": "Pending Review"}):
		doc = frappe.get_doc("HR Site", site_name) if frappe.db.exists("HR Site", site_name) else None
		if doc and doc.possible_duplicate_of:
			create_for_site(doc)          # sites flagged before reports existed still get a trail
	resolve(site_name, status, remarks, **extra)


def _archive_site(doc, reason, target, trees):
	"""Copy of a site (photo, location, snapshot, which trees moved where) into HR Deleted Site."""
	card = _site_card(doc.name) or frappe._dict(photo=None)
	return frappe.get_doc({
		"doctype": "HR Deleted Site", "original_site": doc.name, "site_name": doc.site_name, "photo": card.photo,
		"reason": reason, "possible_duplicate_of": doc.possible_duplicate_of, "moved_to": target,
		"trees_moved": ", ".join(trees) if target else "", "deleted_by": frappe.session.user,
		"deleted_on": frappe.utils.now_datetime(), "site_type": doc.site_type, "status_at_delete": doc.status,
		"zone": doc.zone_id, "road": doc.road, "area": doc.area, "gps_lat": doc.gps_lat, "gps_lng": doc.gps_lng,
		"tree_count": doc.tree_count, "snapshot": json.dumps(doc.as_dict(), default=str, indent=1),
	}).insert(ignore_permissions=True)
